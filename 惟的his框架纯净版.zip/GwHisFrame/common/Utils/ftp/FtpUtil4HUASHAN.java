/*
 * Created on 2005-8-6
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package Utils.ftp;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sun.misc.BASE64Encoder;
import sun.net.TelnetInputStream;
import sun.net.TelnetOutputStream;
import Utils.ftp.cst.FILE_SYNC_STATUS;
import Utils.ftp.entity.FILE_SYNC;
import Utils.ftp.entity.FTPConfig;
import factory.HisInnerFactory;

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FtpUtil4HUASHAN extends FtpUtil {
	
	private static Log log = LogFactory.getLog(FtpUtil4HUASHAN.class);
	
	public String downloadFile(		
			String server, 
	        String user, String passwd,
			String ftp_path,
			String filename) {
		StringBuffer buffer = null;
		MyFTP client = null;
		try {
			client = new MyFTP(server, user, passwd);
			buffer = readFile(client, ftp_path, filename);
			
		} catch (IOException ie) {
			log.error(ie.getMessage());
		}
        finally {
			try {
				client.closeServer();
			} catch(Throwable t) {
				log.error(t.getMessage());
			}
		}
		return null==buffer?"":buffer.toString();
	}
	public String downloadFile2(		
			String server, 
			String user, String passwd,
			String ftp_path,
			String filename) {
		String buffer = null;
		MyFTP client = null;
		try {
			client = new MyFTP(server, user, passwd);
			buffer = readFile2(client, ftp_path, filename);
//			int rtn = buffer.toString().trim().length()==0?FILE_SYNC_STATUS.ASYNC:FILE_SYNC_STATUS.NORMAL;
//			FTPConfig config = ServiceFactory.getInstance().getFTPConfig();
//			if (FILE_SYNC_STATUS.NORMAL == rtn && true == config.DOUBLE_BAK) {
//				;
//			}
			
		} catch (IOException ie) {
			log.error(ie.getMessage());
		}
		finally {
			try {
				client.closeServer();
			} catch(Throwable t) {
				log.error(t.getMessage());
			}
		}
		return null==buffer?"":buffer;
	}
	
	public String downloadFile(		
			String server, 
			String bak_ser,
	        String user, 
	        String passwd,
			String ftp_path,
			String filename,
			int id) {
		FILE_SYNC fs = new FILE_SYNC(server, FILE_SYNC_STATUS.NORMAL, id, filename, ftp_path);
		fs.loadSyncInfoByID();
		String result = downloadFile(fs.MAIN_IP, user, passwd, ftp_path, filename);
		if (result.trim().length()<1) {
			if (fs.STATUS == FILE_SYNC_STATUS.NORMAL) {
				result = downloadFile(fs.MAIN_IP.equals(server)?bak_ser:server, user, passwd, ftp_path, filename);
			}
		}
		return result;
	}
	
	private static StringBuffer readFile(MyFTP client, String ftp_path, String filename) throws IOException {
		StringBuffer buffer = new StringBuffer();
		client.cd(ftp_path);
        BufferedReader bis = new BufferedReader(new InputStreamReader(client.get(filename)));
        String temp = "";
        while((temp=bis.readLine())!=null) {
        	buffer.append(temp);
        	buffer.append("\r\n");
        }
        bis.close();
        
		return buffer;
	}

//	�ϴ��ļ�
	private  String readFile2(MyFTP client, String ftp_path, String filename) throws IOException {
		client.cd(ftp_path);
		byte[] data=null;
		try{
			
			
			TelnetInputStream in =  client.get(filename);
			System.err.println("�ļ��Ƿ���ڣ�"+	client.fileExist(filename)+"in="+ in.available());
		     //InputStream in = client.get(filename);
			data = new byte[in.available()];
			in.read(data);
			in.close();
//			System.out.println("��ȡ�ļ��ɹ�,data����="+data.length +"�ļ�����="
//					+filename+" ·��="+ftp_path);
//			
			
		}catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("û�л�ȡ���ļ�");
		}
		BASE64Encoder encoder = new BASE64Encoder();
		String string = encoder.encode(data);
	    System.out.println(string);
		return string;
	}
	
//	�ϴ��ļ�
	public int put(String fname, byte[] data, 
			String _server, 
			String _user,
			String _passwd,
			String _storePath,
			String path) {
		int rtn = -1;
		MyFTP client = null;
		try {
			client = new MyFTP(_server, _user, _passwd);
			rtn = (-1==writeFile(client, _storePath, path, fname, data))?FILE_SYNC_STATUS.ASYNC:FILE_SYNC_STATUS.NORMAL;	//1Ϊ���洢д��ʧ��,0Ϊ�ɹ�
			FTPConfig config = HisInnerFactory.getInstance().getFTPConfig();
			if (FILE_SYNC_STATUS.NORMAL == rtn && true == config.DOUBLE_BAK) {
				try {
					client.closeServer();
				} catch(IOException ex){}
				try {
					client = new MyFTP(config.IPBAK, _user, _passwd);
					rtn = (-1==writeFile(client, _storePath, path, fname, data))?FILE_SYNC_STATUS.ASYNC:FILE_SYNC_STATUS.NORMAL;	
				} catch(Exception ex) {
					rtn = FILE_SYNC_STATUS.ASYNC;
				}
			}
		} catch (Throwable t) {
			log.error("FtpUtil.put", t);
			convertIP();
			return rtn;
		}
		finally {
			try {
				if (null != client)
					client.closeServer();
			}
			catch (IOException ie) {
				log.error(ie.getMessage());
			}
		}
		return rtn;
	}
	
	public synchronized static void convertIP() {
		FTPConfig config = HisInnerFactory.getInstance().getFTPConfig();
		String tempIP = config.IP;
		config.IP     = config.IPBAK;
		config.IPBAK  = tempIP;	
		log.info("FTP�������л� IP: "+ config.IPBAK+"-->"+config.IP);
	}
	
	private static int writeFile(MyFTP client, String storePath, String path, String fileName, byte[] data) {
		int rtn = -1;
		try {
			client.cd(storePath);
	        try {
	        	client.cd(path);
	        }catch(IOException e) {
	        	client.makeDir(path);
	        	client.cd(path);
	        }
	        TelnetOutputStream out = client.put(fileName);
	        out.write(data);
	        out.flush();
	        out.close();
	        rtn = 0;
		} catch(Throwable t) {
			log.error("FtpUtil.writeFile", t);
		}
		return rtn;
	}
	
}