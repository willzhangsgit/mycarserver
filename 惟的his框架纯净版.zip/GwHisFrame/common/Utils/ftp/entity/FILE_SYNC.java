package Utils.ftp.entity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import tool.Util;
import factory.ServiceFactory;
import factory.SpringFactory;

public class FILE_SYNC {

	private static Log log = LogFactory.getLog(FILE_SYNC.class);
	
	public String MAIN_IP;
	
	public String FILE_NAME;
	
	public String FILE_PATH;
	
	public int STATUS;
	
	public int ID;
	
	public FILE_SYNC(String ip, int status, int id, String fileName, String filePath) {
		MAIN_IP = ip;
		STATUS  = status;
		ID 		= id;	
		FILE_NAME = fileName;
		FILE_PATH = filePath;
	}
	
	public FILE_SYNC loadSyncInfoByID() {
		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;
		try {
			conn = ServiceFactory.getInstance().getDataSource().getConnection();
			String sql = "select * from FILE_SYNC where ID=?";
			prep = conn.prepareStatement(sql);
			prep.setInt(1, ID);
			rs = prep.executeQuery();
			while (true==rs.next()) {
				this.ID = rs.getInt("ID");
				this.MAIN_IP = rs.getString("main_ip");
				this.STATUS = rs.getInt("status");
				this.FILE_NAME = rs.getString("file_name");
				this.FILE_PATH = rs.getString("file_path");
				break;
			}
		} catch (Throwable t) {
			log.error("FILE_SYNC.loadSyncInfoByID", t);
		} finally {
			Util.closeConn(rs, prep, conn);
		}
		return this;
	}
	
	public int insertSyncInfo() {
		Connection conn = null;
		PreparedStatement prep = null;
		int rtn = -1;
		try {
			conn = ServiceFactory.getInstance().getDataSource().getConnection();
			String sql = "insert into FILE_SYNC (ID,STATUS,MAIN_IP,FILE_NAME,FILE_PATH,CRE_TIME,UPDATE_TIME) values(?,?,?,?,?,sysdate,sysdate)";
			prep = conn.prepareStatement(sql);
			prep.setInt(1, ID);
			prep.setInt(2, STATUS);
			prep.setString(3, MAIN_IP);
			prep.setString(4, FILE_NAME);
			prep.setString(5, FILE_PATH);
			rtn = prep.executeUpdate()>=0?0:rtn;
		} catch (Throwable t) {
			log.error("FILE_SYNC.insertSyncInfo", t);
		} finally {
			Util.closeConn(null, prep, conn);
		}
		return rtn;
	}
	
	public int updateSyncInfo() {
		Connection conn = null;
		PreparedStatement prep = null;
		int rtn = -1;
		try {
			conn = ServiceFactory.getInstance().getDataSource().getConnection();
			String sql = "update FILE_SYNC set STATUS=?, MAIN_IP=?, FILE_NAME=?, FILE_PATH=?, UPDATE_TIME=sysdate where ID=?";
			prep = conn.prepareStatement(sql);
			prep.setInt(1, STATUS);
			prep.setString(2, MAIN_IP);
			prep.setInt(5, ID);
			prep.setString(3, FILE_NAME);
			prep.setString(4, FILE_PATH);
			rtn = prep.executeUpdate()>=0?0:rtn;
		} catch (Throwable t) {
			log.error("FILE_SYNC.updateSyncInfo", t);
		} finally {
			Util.closeConn(null, prep, conn);
		}
		return rtn;
	}
	
}
