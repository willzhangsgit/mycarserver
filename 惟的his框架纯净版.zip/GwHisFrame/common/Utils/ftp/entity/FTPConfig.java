package Utils.ftp.entity;


public class FTPConfig {

	public String IP;	//���ļ������� IP
	public String IPBAK; //���ļ������� IP
	public boolean DOUBLE_BAK; //ʹ��˫��д����
	
	public boolean USE_FTP;
	public String USER;		//�ļ������� �û���
	public String PWD;		//�ļ������� ����
	
	public String EMRDIR; 	//������Ŀ¼
	public String EMRPATH;	//�����ļ�·��
	public String EMR_TRAIL_PATH;	//�����޸ĺۼ��ļ�·��
	public String EMR_TEMPLATE_PATH;//����ģ��·��
	
	public String BILLDIR; 	//���뵥��Ŀ¼
	public String BILLPATH;	//���뵥�ļ�·��
	public String BILL_TEMPLATE_PATH;//���뵥ģ��·��
	
	public String ENRDIR; 	//�����ĵ���Ŀ¼
	public String ENRPATH;	//�����ĵ��ļ�·��
	public String ENR_TEMPLATE_PATH;//�����ĵ�ģ��·��

	public String DIAGNOSIS_PATH;//�������ݿ��ļ����λ��
	
	public String DOCTORSETTING_PATH;//ҽ������վ�û���������·��

	
	public String getEMR_TRAIL_PATH() {
		return EMR_TRAIL_PATH;
	}

	public void setEMR_TRAIL_PATH(String eMRTRAILPATH) {
		EMR_TRAIL_PATH = eMRTRAILPATH;
	}

	public String getIP() {
		return IP;
	}

	public void setIP(String iP) {
		IP = iP;
	}

	public String getIPBAK() {
		return IPBAK;
	}

	public void setIPBAK(String iPBAK) {
		IPBAK = iPBAK;
	}

	public boolean isDOUBLE_BAK() {
		return DOUBLE_BAK;
	}

	public void setDOUBLE_BAK(boolean dOUBLEBAK) {
		DOUBLE_BAK = dOUBLEBAK;
	}

	public boolean isUSE_FTP() {
		return USE_FTP;
	}

	public void setUSE_FTP(boolean uSEFTP) {
		USE_FTP = uSEFTP;
	}

	public String getUSER() {
		return USER;
	}

	public void setUSER(String uSER) {
		USER = uSER;
	}

	public String getPWD() {
		return PWD;
	}

	public void setPWD(String pWD) {
		PWD = pWD;
	}

	public String getEMRDIR() {
		return EMRDIR;
	}

	public void setEMRDIR(String eMRDIR) {
		EMRDIR = eMRDIR;
	}

	public String getEMRPATH() {
		return EMRPATH;
	}

	public void setEMRPATH(String eMRPATH) {
		EMRPATH = eMRPATH;
	}

	public String getEMR_TEMPLATE_PATH() {
		return EMR_TEMPLATE_PATH;
	}

	public void setEMR_TEMPLATE_PATH(String eMRTEMPLATEPATH) {
		EMR_TEMPLATE_PATH = eMRTEMPLATEPATH;
	}

	public String getBILLDIR() {
		return BILLDIR;
	}

	public void setBILLDIR(String bILLDIR) {
		BILLDIR = bILLDIR;
	}

	public String getBILLPATH() {
		return BILLPATH;
	}

	public void setBILLPATH(String bILLPATH) {
		BILLPATH = bILLPATH;
	}

	public String getBILL_TEMPLATE_PATH() {
		return BILL_TEMPLATE_PATH;
	}

	public void setBILL_TEMPLATE_PATH(String bILLTEMPLATEPATH) {
		BILL_TEMPLATE_PATH = bILLTEMPLATEPATH;
	}

	public String getENRDIR() {
		return ENRDIR;
	}

	public void setENRDIR(String eNRDIR) {
		ENRDIR = eNRDIR;
	}

	public String getENRPATH() {
		return ENRPATH;
	}

	public void setENRPATH(String eNRPATH) {
		ENRPATH = eNRPATH;
	}

	public String getENR_TEMPLATE_PATH() {
		return ENR_TEMPLATE_PATH;
	}

	public void setENR_TEMPLATE_PATH(String eNRTEMPLATEPATH) {
		ENR_TEMPLATE_PATH = eNRTEMPLATEPATH;
	}

	public String getDIAGNOSIS_PATH() {
		return DIAGNOSIS_PATH;
	}

	public void setDIAGNOSIS_PATH(String dIAGNOSISPATH) {
		DIAGNOSIS_PATH = dIAGNOSISPATH;
	}

	public String getDOCTORSETTING_PATH() {
		return DOCTORSETTING_PATH;
	}

	public void setDOCTORSETTING_PATH(String dOCTORSETTING_PATH) {
		DOCTORSETTING_PATH = dOCTORSETTING_PATH;
	}
	
}
