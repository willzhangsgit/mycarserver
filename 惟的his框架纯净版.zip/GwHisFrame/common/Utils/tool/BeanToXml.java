package Utils.tool;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import cst.ParamsConst;

import xml.XMLGenerate;
import xml.entity.ListData;

public class BeanToXml {
	
	public static void beanToXml(XMLGenerate gen,Object obj,String xmlName) throws Exception, Exception{
		ListData xmldata = new ListData();
		xmldata.Name = xmlName;
		 Field[] fs = obj.getClass().getDeclaredFields();
		 for(Field f: fs){
			 String getMothname = "get"+f.getName().substring(0,1).toUpperCase()+f.getName().substring(1,f.getName().length());
			 Method m = obj.getClass().getMethod(getMothname, null);
			System.out.println(m.getName());
			 Object value = m.invoke(obj, null);
			 if(value!=null){
				 xmldata.appendXMLData(f.getName(),value.toString(), ParamsConst.STRING);
			 }else{
				 xmldata.appendXMLData(f.getName(),"", ParamsConst.STRING);
			 }
		 }
		 gen.addValue(xmldata);
		 
	}

}
