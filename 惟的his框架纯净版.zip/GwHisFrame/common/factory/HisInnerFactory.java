package factory;

import Utils.ftp.FtpUtil;
import Utils.ftp.entity.FTPConfig;

public class HisInnerFactory extends SpringFactory {

	public static HisInnerFactory getInstance() 
	{
		getContext();
		return __instance;
	}
	
	public FTPConfig getFTPConfig()
	{
		return (FTPConfig)__ctx.getBean("FTPConfig");
	}
	
	public FtpUtil getFTPUtil()
	{
		return (FtpUtil)__ctx.getBean("FTPUtil");
	}
	
	private static HisInnerFactory __instance = new HisInnerFactory();
	
	private HisInnerFactory(){}
}
