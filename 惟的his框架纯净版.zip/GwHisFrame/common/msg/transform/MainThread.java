package msg.transform;

import java.util.ArrayList;
import java.util.List;

import msg.transform.strategy.IMsgStragtegy;

public class MainThread implements Runnable {

	public void run() {
		while(true)
		{
			execute();
			try {
				Thread.sleep(1000*60);
			}catch(Throwable t){}
		}
	}
	
	public MainThread()
	{
		_strategys.clear();
	}
	
	private List<IMsgStragtegy> _strategys = new ArrayList<IMsgStragtegy>(2); 
	
	public static void main(String[] str) {
		new MainThread().execute();
	}

	public void execute()
	{
		for (IMsgStragtegy s:_strategys) {
			s.execute();
		}
	}
	
}
