package msg.transform.strategy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import tool.Assert;
import base.dao.IBaseDAO;
import base.dao.impl.BaseDAOImpl;

public abstract class BasicStragtegy implements IMsgStragtegy {

	protected String getMail(String docid) {
		Connection conn = _dao.getConnection();
		String mail = "";
		
		return mail;
	}
	
	protected IBaseDAO _dao = new BaseDAOImpl();
}
