package msg.transform.strategy;


public interface IMsgStragtegy {

	public abstract void execute();
	
}
