package msg.transform.strategy.broadcast;

import java.util.HashMap;
import java.util.Map;
import cst.MsgConst;

public class BroadcastNameListFactory {

	private Map<String, IBroadcastNameList> __contrainers = new HashMap<String, IBroadcastNameList>(10);
	
	private BroadcastNameListFactory() {

	}
	
	private static BroadcastNameListFactory __instance = new BroadcastNameListFactory();
	
	public static BroadcastNameListFactory getInstance() {
		return __instance;
	}
	
	public IBroadcastNameList getNameListPack(String type) {
		IBroadcastNameList rtn = null;
		String key = type.toUpperCase();
		if (__contrainers.containsKey(key))
			rtn = __contrainers.get(key);
		else
			rtn = new DefaultNameList();
		return rtn;
	}
}
