package msg.transform.strategy.broadcast;

import java.util.ArrayList;
import java.util.List;

public class DefaultNameList implements IBroadcastNameList {

	@Override
	public List<String> getNameList(String code) {
		// TODO Auto-generated method stub
		return new ArrayList<String>();
	}

}
