package msg.transform.strategy.broadcast;

import java.util.List;

public interface IBroadcastNameList {

	public List<String> getNameList(String code);
}
