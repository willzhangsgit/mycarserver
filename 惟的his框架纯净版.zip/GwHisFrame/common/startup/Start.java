package startup;

import msg.transform.MainThread;

public class Start {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Run();
	}
	 
	public static void Run() {
		new Thread(new MainThread()).start();
	}

}
