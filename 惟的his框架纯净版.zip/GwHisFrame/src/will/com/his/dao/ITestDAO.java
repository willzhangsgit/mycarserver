package will.com.his.dao;


public interface ITestDAO {
 public String TestProcedure();
}
