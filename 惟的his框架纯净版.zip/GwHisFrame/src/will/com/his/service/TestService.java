package will.com.his.service;


import log.ILog;


import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import factory.InnerFactory;

import tool.Assert;
import tool.data.*;
import xml.XMLGenerate;
import xml.XMLParse;
import base.dao.IBaseDAO;
import base.service.ServiceAdaptor;

@Scope("prototype")
@Service("will.com.his.service.TestService")
public class TestService extends ServiceAdaptor {
	
	@Override
	public void afterExecute() {
		// TODO Auto-generated method stub
		super.afterExecute();
	}


	@Override
	public boolean beforeExecute(String code, String addr) {
		// TODO Auto-generated method stub
		return super.beforeExecute(code, addr);
	}


	@Override
	protected boolean isTransaction() {
		return true;
	}


	@Override
	public void handleException(Throwable t) {
		// TODO Auto-generated method stub
		super.handleException(t);
	}

	@Override
	public void initSource() {
		// TODO Auto-generated method stub
		super.initSource();
	}

	@Override
	public void releaseSource() {
		// TODO Auto-generated method stub
		super.releaseSource();
	}

	@Override
	public String doExecute(XMLParse parse) throws Throwable {
		String pid = parse.getParamValue("pid");
		System.out.println(pid);
		ILog log = this.getLogObject();
		log.makeLogInfo("this is a test");
		XMLGenerate gen = XMLGenerate.getInstance();
		Assert.isTrue(true, "");
		
		return gen.toXML();
	}
	
	@Override
	protected void setLogObject(ILog log) {
		// TODO Auto-generated method stub
		super.setLogObject(log);
	}


	@Override
	public void setLogObject(String logPath) {
		// TODO Auto-generated method stub
		super.setLogObject(logPath);
	}


	public static void main(String[] str) {
		/*IBaseDAO base = (IBaseDAO)InnerFactory.getInstance().getObject("baseDAO");
		ProcedureLite proc = base.createProcedure("hu_clinic.testc");
		proc.appendParam("cursor", ProType.Cursor);
		proc.appendParam("int", ProType.Int);
		base.callProcedure(proc);*/
		
//		String msg = "tetetetttetetet";
//		Logger __log = Logger.getLogger(TestService.class);
//		if (__log.isDebugEnabled()) {
//			__log.debug(msg);
//			return;
//		}
//		if (__log.isInfoEnabled()) {
//			__log.info(msg);
//			return;
//		}
//		if (__log.isEnabledFor(Level.ERROR)) {
//			__log.error(msg);
//			return;
//		}
//		IBaseDAO base = (IBaseDAO)InnerFactory.getInstance().getObject("baseDAO");
//		System.out.println(base);
	}
	
}
